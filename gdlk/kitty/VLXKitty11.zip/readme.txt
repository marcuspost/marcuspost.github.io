VLX Kitty Firmware v1.1 

Changelog:
-Stick was always forced to dpad+Left analog stick mode. Re-inserted option to control by holding Start or Select on plug in. Fixes compatability problem with SF4 AE. 


To flash this firmware onto you VLX Kitty board, run the included 'Kitty.exe' program. Click the button 'Update Firmware', and select the file 'vlxkitty_complete_11.hex'. A window will pop up asking you to hold down the Guide button and plug in the stick to your PC; do so. Once you see the upper left and lower right LEDs around the guide button light up, click 'Ok' on that window and the firmware update will run. If you are asked for permission to run the update program, click 'Yes'.
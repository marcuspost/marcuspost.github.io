VLX Kitty Firmware v1.0 

Changelog:
-Initial release


To flash thsi firmware onto you VLX Kitty board, plug the arcade stick into a PC with the Xbox 'Guide' button held. You should see the upper left and lower right player inticator LEDs light up to show you are in bootloader mode. Doubleclick 'runasadm.bat'. Leave arcade stick plugged in until flash is complete. 
If you see an error message about permissions, right-click on 'fw_update.exe', select Properties -> Compatibility tab, and check the box 'Run this program as an administrator' and try again. 

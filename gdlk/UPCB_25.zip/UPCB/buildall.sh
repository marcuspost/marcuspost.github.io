rm -f _output/UPCB_$1_*.hex
make clean
make "DEFFLAGS= -DPROGRAM_BUTTON -DEXTRA_BUTTONS_LEFT"
mv UPCB.hex ./_output/UPCB_$1_BP.hex
make clean
make "DEFFLAGS= -DPROGRAM_BUTTON" 
mv UPCB.hex ./_output/UPCB_$1_XP.hex
make clean
make "DEFFLAGS= -DEXTRA_BUTTONS_LEFT"
mv UPCB.hex ./_output/UPCB_$1_B.hex
make clean
make
mv UPCB.hex ./_output/UPCB_$1_X.hex
make clean
make "DEFFLAGS= -DPROGRAM_BUTTON -DSTATUS_LEDS"
mv UPCB.hex ./_output/UPCB_$1_LP.hex
make clean
make "DEFFLAGS= -DSTATUS_LEDS"
mv UPCB.hex ./_output/UPCB_$1_L.hex
make clean
cd ..
zip -r UPCB_$1.zip UPCB/
cd UPCB

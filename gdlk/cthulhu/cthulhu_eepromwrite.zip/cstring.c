#include <stdio.h>
#include <usb.h>
#include <string.h>
#define FALSE   0
#define TRUE    1

#define SET_RATE            0x01
#define SET_DISPLAY_BUFFER  0x02
#define GET_DISPLAY_BUFFER  0x03
int dev_found;
struct usb_device *dev;
usb_dev_handle *udev;
char string[]={	0,0,0,0,0,0,0,0,0,0,
					0,0,0,0,0,0,0,0,0,0,
					0,0,0,0,0,0,0,0,0,0,
					0,0,0,0,0,0,0,0,0,0,
					0,0,0,0,0,0,0,0,0,0, //50
					0,0,0,0,0,0,0,0,0,0,
					0,0,0,0,0,0,0,0,0,0,
					0,0,0,0,0,0,0,0,0,0,
					0,0,0,0,0,0,0,0,0,0,
					0,0,0,0,0,0,0,0,0,0, //100
					0,0,0,0,0,0,0,0,0,0,
					0,0,0,0,0,0,0,0,0,0,
					0,0,0,0,0,0,0,0,0,0 };


void enumerate(int vid, int pid)
{
	struct usb_bus *bus;
	usb_init();

    usb_find_busses();
    usb_find_devices();

    udev = NULL;
    dev_found = FALSE;
    for (bus = usb_get_busses(); bus && !dev_found; bus = bus->next) {
        for (dev = bus->devices; dev && !dev_found; dev = dev->next) {
            if ((dev->descriptor.idVendor == vid) &&
						(dev->descriptor.idProduct == pid)) {
                dev_found = TRUE;
                udev = usb_open(dev);
            }
        }
    }

}

int eepromput(unsigned char address, unsigned char data)
{
	unsigned char buffer[0x2];
	int i;
	i = usb_control_msg(
					udev, //device handle, duh
					/*  0 (host to device)
						10 (vendor)
						00000 (device)
						0100 0000 = 0x40 */
					0x40, //requesttype
					0xEA, //request
					((data<<8)+(address)), //value
					0x0000, //index (??)
				  buffer,
					0x0001,
					1000);
	if(i<0) //error
	{ 
		return(-1);
	}
	else
	{//all good, return value
		return buffer[0];
	}
}

unsigned char eepromget(unsigned char address)
{
	unsigned char buffer[0x2];
	int i;
	i = usb_control_msg(
					udev, //device handle, duh
					/*  0 (host to device)
						10 (vendor)
						00000 (device)
						0100 0000 = 0x40 */
					0xC1, //requesttype
					0xEB, //request
					address, //value
					0x0000, //index (??)
				  buffer,
					0x0001,
					1000);
	if(i<0) //error
	{ 
		return(0);
	}
	else
	{//all good, return value
		return buffer[0];
	}
}

int calculatepid(char *string)
{
	int i,result;
	result=0;
	for(i=0;i<strlen(string);i++)
	{
		result=result+string[i];
	}
	while(result>0xFFFF) result -= 0xFFFF;
	return(result);

}

char *currentstring(void)
{
	
	int i,j,numchars;
	for(i=0;i<130;i++) string[i]=0x00;
	//get bytes in packet (#3)
	i=eepromget(3);
	numchars= (i-2)/2;
	for(j=0;j<numchars;j++)
		string[j]=eepromget((j*2)+5);
	return(string);
}

void setflag(void)
{
	eepromput(0x00, 'C');
}

unsigned char getflag(void)
{
	return(eepromget(0x00));
}
unsigned char getsize(void)
{
	return(eepromget(0x03));
}
void setsize(unsigned char size)
{
	eepromput(0x03, size);
}
unsigned char gettype(void)
{
	return(eepromget(0x04));
}
void settype(void)
{
	eepromput(0x04, 0x03);
}


int getpid(void)
{
	return((eepromget(0x01)<<8)+eepromget(0x02));
}
void setpid(int pid)
{
	unsigned char high, low;
	high = pid>>8;
	low = pid - (high << 8);
	eepromput(0x01, high);
	eepromput(0x02, low);
}

void setbinstring(char *string)
{
	int i, address;
	for(i=0;i<250;i++)eepromput(1, 0x00);	
	for(i=0;i<strlen(string);i++)
	{ //for each character in the string
		address=(i)+5;
		eepromput(address,string[i]);
		//eepromput(address, 0x00);	
	}
	//string entered, now save the length of the fields. 
	setsize((strlen(string))+2);
	//save the flag
	setflag();
	setpid(calculatepid(string)+0xA0);
	settype();
}

void setstring(char *string)
{
	int i, address;
	for(i=0;i<250;i++)eepromput(1, 0x00);	
	for(i=0;i<strlen(string);i++)
	{ //for each character in the string
		address=(i*2)+5;
		eepromput(address,string[i]);
		eepromput(address+1, 0x00);	
	}
	//string entered, now save the length of the fields. 
	setsize((strlen(string)*2)+2);
	//save the flag
	setflag();
	setpid(calculatepid(string));
	settype();
}

int main(int argc, char *argv[]) {
    
    
    int ret,i;
    if (argc!=2)
	{
		printf("No arguments specified, or more than one argument specified.\n");
		printf("If string to write contains spaces, make sure to wrap them in \n");
		printf("doublequotes like this: cstring \"My New String\" \n");
		return(-2);
	}
    
    usb_init();

    usb_find_busses();
    usb_find_devices();

	enumerate(0x14d8,0x101f);
    if (!dev_found) {
        printf("No matching device found...\n");
		return(-1);
    }
	
	printf("Current string: \"%s\"\n",currentstring());
	printf("Current PID: %.4x\n", getpid());
	printf("Current size: %d \n", getsize());
	printf("Current type: %d \n", gettype());
	printf("Calculated PID: %.4x\n",calculatepid(argv[1]));
	printf("Setting string to : \"%s\"\n",argv[1]);
	setstring(argv[1]);
	//setbinstring(binstring);
	printf("Current string: \"%s\"\n",currentstring());
	printf("Current PID: %.4x\n", getpid());
	printf("Current size: %d \n", getsize());
	printf("Current type: %d \n", gettype());
	
		
}

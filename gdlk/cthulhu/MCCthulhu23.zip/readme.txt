Multi-Console Cthulhu Firmware v2.3 

Changelog:
-Directional inputs cleaned to prevent simultaneous opposite cardinal directions. 
	Up+Down=Up, and Left+Right=Neutral. 
-Changed Start+select=Home code. S+S=G will now work properly in both PS3 and Xbox360 modes. If you are dual modding, you CANNOT use the DISABLE_HOME jumper on the board itself. If you are not dual modding, it shouldn't matter, but it is best if you don't use it. There is a saved flag that remembers if you want to have S+S=G; hold down Forward+Roundhouse (2K+3K) on plug in, and it will toggle the S+S=G setting. 
-Includes both 10ms and 1ms speeds for PC/PS3 play. If you experience any stability problems with the 1ms version, either downgrade to the 10ms version, or upgrade your USB cable to a higher speed cable. 

Usage:
Plug your MC Cthulhu into your PC with the Start and Select buttons held down. Run the included Bootloader.exe. Bootloader window will indicate if the MC Cthulhu is connected in bootloader mode; if it is, click Open and select the included cthulhu.2.3.hex file. Press 'Program' and let it run. The window will indicate if the firmware updated completed successfully. 

Note:
The 'Verify' button in the bootloader program is currently broken. The 'Program' step automatically verifies during write, so if the 'Program' says it completed successfully, it did in fact complete successfully. 
Requires .Net to run. 
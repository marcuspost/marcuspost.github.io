Multi-Console Cthulhu Firmware v. 1.6

Changelog:
1. TurboGrafx-16/PC-Engine support added. Press 'Home' (or Start and Select together if Home is disabled) to cycle through the available
	modes. Please be aware that the MC Cthulhu can only behave as a six button controller if connected through a multi-tap. When 
	directly connected to the console, the MC Cthulhu can only behave as a normal two button controller. 
2. Holding 1P and 3K (and nothing else) when plugging in the MC Cthulhu will overwirte the USB string. Should only be used if your USB 
	string has become corrupt for some reason.
3. Self-test mode. Connecting Select and Start together with a piece of wire will force the Cthulhu into a basic mode to show that code is running on the board. This code will toggle the Up screw terminal high and low every 2 seconds; this point can be tested with the multimeter or by connecting an LED to Up and the nearby VCC screw terminal. 

Usage:
Plug your MC Cthulhu into your PC with the Start and Select buttons held down. Run the included Bootloader.exe. Bootloader window will indicate if the MC Cthulhu is connected in bootloader mode; if it is, click Open and select the included cthulhu.1.6.hex file. Press 'Program' and let it run. The window will indicate if the firmware updated completed successfully. 

Note:
The 'Verify' button in the bootloader program is currently broken. The 'Program' step automatically verifies during write, so if the 'Program' says it completed successfully, it did in fact complete successfully. 
Requires .Net to run. 
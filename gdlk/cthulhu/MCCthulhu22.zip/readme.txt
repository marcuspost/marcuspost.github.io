Multi-Console Cthulhu Firmware v2.2 beta

Changelog:
Added support for Xbox360 autodetection using v2 Imps

Usage:
Plug your MC Cthulhu into your PC with the Start and Select buttons held down. Run the included Bootloader.exe. Bootloader window will indicate if the MC Cthulhu is connected in bootloader mode; if it is, click Open and select the included cthulhu.2.2.hex file. Press 'Program' and let it run. The window will indicate if the firmware updated completed successfully. 

Note:
The 'Verify' button in the bootloader program is currently broken. The 'Program' step automatically verifies during write, so if the 'Program' says it completed successfully, it did in fact complete successfully. 
Requires .Net to run. 
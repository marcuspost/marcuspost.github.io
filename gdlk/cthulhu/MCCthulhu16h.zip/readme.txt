Multi-Console Cthulhu Firmware v. 1.6h (Release Candidate 3 for 2.0)

Changelog:
1. Bugfix: NES, erratic behavior in Turbo mode in some games
2. PSX: Added a 'converter' mode that assigns both R2 and L1 to the 3K button, and assigned both X and Start to the 'Select' button. Intended to help with Dreamcast converter use. Hit Guide to toggle from normal PSX mode to converter mode and back. 

Usage:
Plug your MC Cthulhu into your PC with the Start and Select buttons held down. Run the included Bootloader.exe. Bootloader window will indicate if the MC Cthulhu is connected in bootloader mode; if it is, click Open and select the included cthulhu.1.6h.hex file. Press 'Program' and let it run. The window will indicate if the firmware updated completed successfully. 

Note:
The 'Verify' button in the bootloader program is currently broken. The 'Program' step automatically verifies during write, so if the 'Program' says it completed successfully, it did in fact complete successfully. 
Requires .Net to run. 
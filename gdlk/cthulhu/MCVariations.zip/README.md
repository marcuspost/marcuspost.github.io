#MC Cthulhu Variations

This a small set of requested custom firmwares for specific features/issues

## Cthulhu2.3.SOCD_UDN.hex

Instead of the usual Up+Down=Up solution for SOCD's, this uses Up+Down=Neutral.
Left+Righ=Neutral remains the same.

## MCCthulhu23_RetroPieCompat.hex

My memory is fuzzy, but I believe the only change here was to skip the usual
Xbox360 detection and go into normal PS3 USB mode by default, since the Xbox360
detection tends to trigger on Linux systems. 

## MCCthulhu_Popn.hex

Playstation 1 mode skips SOCD cleanings, and reports SOCDs like Right+Left and
Up+Down exactly as detected by the controller. This is mean to be used for
wiring a MC Cthulhu into a Pop'n'Music, which connects the directions to buttons
instead of a joystick lever. 

Collected for posterity, Toodles May 2019

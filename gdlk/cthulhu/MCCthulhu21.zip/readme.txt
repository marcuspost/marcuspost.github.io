Multi-Console Cthulhu Firmware v. 2.1

Changelog:
1. PSX: DC Converter mode is now activated by holding 3P and 3K when plugging in. 
2. PSX: DC Converter mode changed so Select button outputted the PSX Select button instead of the previous 'Start+X' combination. 
3. PSX: DC Converter mode changed so pressing Home now does the 'Start+X' combination usually used for taunting in Dreamcast Capcom fighters.
4. PSX: Normal mode pressing Home now activates Select and Up, the combination seen by most PSX->360 converters to interpret as the Guide button.
5. Xbox: Extended commands, previously activated by holding Select, are now done by holding Home. 

Usage:
Plug your MC Cthulhu into your PC with the Start and Select buttons held down. Run the included Bootloader.exe. Bootloader window will indicate if the MC Cthulhu is connected in bootloader mode; if it is, click Open and select the included cthulhu.2.1.hex file. Press 'Program' and let it run. The window will indicate if the firmware updated completed successfully. 

Note:
The 'Verify' button in the bootloader program is currently broken. The 'Program' step automatically verifies during write, so if the 'Program' says it completed successfully, it did in fact complete successfully. 
Requires .Net to run. 
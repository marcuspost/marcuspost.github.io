Multi-Console Cthulhu Firmware v. 1.5

Changelog:
1. NES and SNES support added. 
2. NES support include Turbo and 'Punch-Out' modes. Press 'Home' (or Start and Select together if Home is disabled) to cycle through the modes Normal -> Turbo -> Punch-Out -> back to Normal. In Turbo mode, the 1P and 2P buttons act as a Turbo version of B and A, respectively. In Punch-Out mode, the 1P and 2P buttons act as Select and Start, respectively. In Normal mode, 1P and 2P don't do anything.
3. Tweak to Gamecube support Smash Brothers modes to fix 'always run' problem when the Run button isn't held down (Smash Advanced mode) or when the direction wasn't doubletapped (Smash Basic mode).

Usage:
Plug your MC Cthulhu into your PC with the Start and Select buttons held down. Run the included Bootloader.exe. Bootloader window will indicate if the MC Cthulhu is connected in bootloader mode; if it is, click Open and select the included cthulhu.1.5.hex file. Press 'Program' and let it run. The window will indicate if the firmware updated completed successfully. 

Note:
The 'Verify' button in the bootloader program is currently broken. The 'Program' step automatically verifies during write, so if the 'Program' says it completed successfully, it did in fact complete successfully. 
Requires .Net to run. 
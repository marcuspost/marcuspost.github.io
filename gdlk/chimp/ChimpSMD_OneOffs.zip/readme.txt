This is a collection of firmwares for the ChimpSMD arcade stick control board. 
Chimp_v11.hex is the officially released firmware, the same one present on all boards sold. 
Chimp_HomeFor360.hex is identical to the official firmware, except the Home button is the shortcut to force Xbox360 mode. 
Chimp_smallerwindow_nodelay.hex reduces the window for Xbox360 detection, so that if an Xbox360 is detected, the switch over to Xbox360 mode takes much less time. 

These alternate firmwares are unsupported and not truly tested. If you have any issues with them, please flash back to the official firmware. 

Plug the ChimpSMD stick into your PC with Start and Select held to go into bootloader mode. Run the ChImpBootLoader.exe application. Click "Open Hex File", select the one you want to flash, and hit "Program". If the messages say it successfully completed, the update is finished. 
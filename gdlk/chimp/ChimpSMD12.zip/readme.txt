Chimp firmware v1.2

Changelog:
-In Xbox360 mode, Start+Select was pulling down the Right direction instead of the Home signal. Corrected.

Plug the ChimpSMD stick into your PC with Start and Select held to go into bootloader mode. Run the ChImpBootLoader.exe application. Click "Open Hex File", select the one you want to flash, and hit "Program". If the messages say it successfully completed, the update is finished. 